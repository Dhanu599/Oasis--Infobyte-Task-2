**TaskCraft Todo App**

TaskCraft is a simple Todo application designed to help users manage their tasks efficiently. This app allows users to create, edit, and delete tasks, ensuring they stay organized and productive.

**Features**

User Authentication: Secure user authentication system with login and signup functionality to protect user data.

Todo List Management: Easily create, edit, and delete tasks to keep track of your daily activities.

SQL Database: Utilizes SQL database to store user login data and todo list items securely.

Recycler View: Implements Recycler View for smooth and efficient display of todo list items.

**Installation**
Clone the repository:

git clone https://github.com/yourusername/TaskCraft.git
Open the project in Android Studio.

Build and run the project on an Android emulator or physical device.


**Usage**

Launch the app and sign up or log in with your credentials.

Once logged in, you'll be presented with the main screen displaying your todo list.

Use the options to add, edit, or delete tasks as needed.

Log out when finished to secure your data.

**Contributing**

Contributions are welcome! Please feel free to fork the repository and submit pull requests to contribute to this project.

**License**

This project is licensed under the MIT License.

**Acknowledgements**

Special thanks to Android Developers for their documentation and resources.
This app was developed as part of a learning project and is for educational purposes only.
