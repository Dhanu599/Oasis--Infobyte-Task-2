package com.Dhanshri.taskcraft;

import android.content.DialogInterface;

public interface DialogCloseListener {
    public void handleDialogClose(DialogInterface dialog);
}
